"""Paired analysis of MasaCtrl vs. our method on PIE-Bench category 8 (change background).

Reads only files already in the repository (no GPU, no PIE-Bench download needed):
  results/baseline+improvement1/metrics_long_category8.csv
  results/baseline+improvement1/{baseline,improvement1}/runtime.jsonl
  results/baseline+improvement1/subject_hints_category8.json
  user_study/responses.csv, user_study/answer_key_DO_NOT_SHARE.csv

Writes
  results/baseline+improvement1/analysis/summary.md      every number quoted in the report
  results/baseline+improvement1/analysis/per_image.csv   paired per-image scores and deltas
  paper/tables/main_results.tex                          Table: 7 metrics, win rate, runtime
  paper/tables/subgroups.tex                             Table: deltas per PIE-Bench sub-group
  paper/tables/user_study.tex                            Table: pairwise preferences + kappa

Usage:  python src/analyze_category8.py
"""
import csv
import json
import re
from math import comb
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results" / "baseline+improvement1"
OUT = RES / "analysis"
TABLES = ROOT / "paper" / "tables"

BASE, OURS = "ddim+masactrl", "Yangyuan"
# key, LaTeX header, scale (PIE-Bench Table 1 convention), +1 if higher is better
METRICS = [
    ("structure_distance", r"Struct.$\downarrow$", 1e3, -1),
    ("psnr_unedit_part", r"PSNR$\uparrow$", 1, +1),
    ("lpips_unedit_part", r"LPIPS$\downarrow$", 1e3, -1),
    ("mse_unedit_part", r"MSE$\downarrow$", 1e4, -1),
    ("ssim_unedit_part", r"SSIM$\uparrow$", 1e2, +1),
    ("clip_similarity_target_image", r"CLIP-W$\uparrow$", 1, +1),
    ("clip_similarity_target_image_edit_part", r"CLIP-E$\uparrow$", 1, +1),
]
SHORT = {"structure_distance": "Struct", "psnr_unedit_part": "PSNR", "lpips_unedit_part": "LPIPS",
         "mse_unedit_part": "MSE", "ssim_unedit_part": "SSIM",
         "clip_similarity_target_image": "CLIP-W", "clip_similarity_target_image_edit_part": "CLIP-E"}
SUBGROUPS = {"11": "Artificial / animal", "12": "Artificial / human", "13": "Artificial / indoor",
             "14": "Artificial / outdoor", "21": "Natural / animal", "22": "Natural / human",
             "23": "Natural / indoor", "24": "Natural / outdoor"}
# Subject hints that name a scene or an adjective instead of a foreground object
# (checked by eye against the generated images; the hint file itself is automatic).
SCENE_HINTS = {"813000000002", "813000000008", "814000000002", "814000000004",
               "814000000007", "823000000006", "824000000006", "824000000008"}


def bootstrap_ci(x, n=10000, seed=0):
    rng = np.random.default_rng(seed)
    means = rng.choice(x, size=(n, len(x)), replace=True).mean(1)
    return np.percentile(means, [2.5, 97.5])


def fmt_p(p):
    if p < 1e-3:
        return f"{p:.1e}"
    return f"{p:.3f}"


def load_metrics():
    d = pd.read_csv(RES / "metrics_long_category8.csv", dtype={"id": str})
    scale = {k: s for k, _, s, _ in METRICS}
    d["value"] = d["value"] * d["metric"].map(scale)
    wide = d.pivot_table(index=["id", "metric"], columns="method", values="value").reset_index()
    wide["sub"] = wide["id"].str[1:3]
    return wide


def load_runtime():
    out = {}
    for folder, method in (("baseline", BASE), ("improvement1", OURS)):
        rows = [json.loads(l) for l in (RES / folder / "runtime.jsonl").read_text().splitlines() if l.strip()]
        out[method] = np.array([r["seconds"] for r in rows])
    return out


def paired_stats(wide):
    rows = []
    for key, _, _, sign in METRICS:
        g = wide[wide.metric == key].dropna(subset=[BASE, OURS])
        b, o = g[BASE].to_numpy(), g[OURS].to_numpy()
        diff = o - b
        lo, hi = bootstrap_ci(diff)
        rows.append(dict(metric=key, n=len(g), base=b.mean(), ours=o.mean(), delta=diff.mean(),
                         ci_lo=lo, ci_hi=hi, ours_better=np.mean(sign * diff > 0),
                         wilcoxon_p=stats.wilcoxon(o, b).pvalue,
                         base_sd=b.std(ddof=1), ours_sd=o.std(ddof=1)))
    return pd.DataFrame(rows).set_index("metric")


ORDER = ["clip_similarity_target_image_edit_part", "clip_similarity_target_image", "psnr_unedit_part",
         "lpips_unedit_part", "mse_unedit_part", "ssim_unedit_part", "structure_distance"]


def main_table(ps, rt):
    meta = {k: (h, sign) for k, h, _, sign in METRICS}
    hdr = (r"& \multicolumn{2}{c}{Edit fidelity} & \multicolumn{4}{c}{Unedited region} & & \\" + "\n"
           r"\cmidrule(lr){2-3}\cmidrule(lr){4-7}" + "\n"
           + " & ".join(["Method"] + [meta[k][0] for k in ORDER] + [r"Time (s)$\downarrow$"]) + r" \\")
    lines = [r"\begin{table*}[t]", r"\centering", r"\small",
             r"\begin{tabular}{l" + "c" * (len(ORDER) + 1) + "}", r"\toprule", hdr, r"\midrule"]
    for method, label in ((BASE, r"DDIM + \method{}"), (OURS, r"DDIM + Proposed")):
        cells = [label]
        for key in ORDER:
            r, sign = ps.loc[key], meta[key][1]
            v, other = (r.base, r.ours) if method == BASE else (r.ours, r.base)
            s_ = f"{v:.2f}"
            cells.append(r"\textbf{" + s_ + "}" if sign * (v - other) > 0 else s_)
        t, t_other = rt[method].mean(), rt[OURS if method == BASE else BASE].mean()
        cells.append(r"\textbf{" + f"{t:.1f}" + "}" if t < t_other else f"{t:.1f}")
        lines.append(" & ".join(cells) + r" \\")
    e = ps.loc["clip_similarity_target_image_edit_part"]
    n_full, n_unedit = int(ps.loc["structure_distance"].n), int(ps.loc["psnr_unedit_part"].n)
    lines += [r"\bottomrule", r"\end{tabular}",
              r"\caption{Results on the 80 PIE-Bench \emph{change background} images. CLIP-E/CLIP-W: CLIP "
              r"similarity between the target prompt and the edited region/whole image. PSNR, LPIPS ($\times10^3$), "
              r"MSE ($\times10^4$) and SSIM ($\times10^2$) are computed outside the edit mask, i.e.\ on the subject "
              rf"({n_unedit} images; the masks of the other {n_full - n_unedit} cover the whole image). "
              r"Structure distance ($\times10^3$) is computed on the whole image and therefore also counts the "
              rf"requested background change. The proposed method raises CLIP-E on {round(e.ours_better * n_full)} of the "
              rf"{n_full} images (paired Wilcoxon $p<10^{{-10}}$). Time: mean seconds per edit on the same GPU.}}",
              r"\label{tab:main}", r"\end{table*}"]
    return "\n".join(lines) + "\n"


def subgroup_stats(wide):
    rows = []
    for sub, name in SUBGROUPS.items():
        r = {"sub": sub, "name": name}
        for key in ("clip_similarity_target_image_edit_part", "clip_similarity_target_image",
                    "structure_distance", "psnr_unedit_part"):
            g = wide[(wide.metric == key) & (wide["sub"] == sub)].dropna(subset=[BASE, OURS])
            r[f"{SHORT[key]}_base"] = g[BASE].mean()
            r[f"{SHORT[key]}_ours"] = g[OURS].mean()
            r[f"d_{SHORT[key]}"] = (g[OURS] - g[BASE]).mean()
            r[f"n_{SHORT[key]}"] = len(g)
            r[f"win_{SHORT[key]}"] = int(((g[OURS] - g[BASE]) > 0).sum())
        rows.append(r)
    return pd.DataFrame(rows)


def subgroup_table(sg):
    lines = [r"\begin{table}[t]", r"\centering", r"\small", r"\setlength{\tabcolsep}{4pt}",
             r"\begin{tabular}{lcccc}", r"\toprule",
             r"Sub-group & \method{} & Proposed & $\Delta$ & Improved \\", r"\midrule"]
    for _, r in sg.iterrows():
        lines.append(f"{r['name']} & {r['CLIP-E_base']:.2f} & \\textbf{{{r['CLIP-E_ours']:.2f}}} & "
                     f"{r['d_CLIP-E']:+.2f} & {r['win_CLIP-E']}/{r['n_CLIP-E']}" + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}",
              r"\caption{Edited-region CLIP similarity (CLIP-E) per PIE-Bench sub-group. $\Delta$ = proposed $-$ "
              r"\method{}; Improved: images on which the proposed method scores higher.}",
              r"\label{tab:subgroups}", r"\end{table}"]
    return "\n".join(lines) + "\n"


# ----------------------------------------------------------------------------- user study
DIMS = [("Image quality", ("清晰", "自然")), ("Prompt fidelity", ("修改要求", "符合")),
        ("Structure preservation", ("主体", "保留"))]


def sign_test(w, l):
    w, l = int(w), int(l)
    n = w + l
    k = min(w, l)
    return min(1.0, 2 * sum(comb(n, i) for i in range(k + 1)) / 2 ** n)


def fleiss_kappa(table):
    """table: items x categories counts, same number of raters per item."""
    table = np.asarray(table, float)
    n = table.sum(1)[0]
    p_j = table.sum(0) / table.sum()
    p_i = ((table ** 2).sum(1) - n) / (n * (n - 1))
    pe = (p_j ** 2).sum()
    return (p_i.mean() - pe) / (1 - pe)


def user_study():
    us = ROOT / "user_study"
    key = {int(r["question"]): r for r in csv.DictReader(open(us / "answer_key_DO_NOT_SHARE.csv"))}
    rows = list(csv.DictReader(open(us / "responses.csv", encoding="utf-8-sig")))
    res = {}
    for dim, kws in DIMS:
        per_q = np.zeros((len(key), 3), int)          # ours, baseline, tie
        per_rater = np.zeros((len(rows), 3), int)
        for col in rows[0]:
            m, br = re.search(r"Q\s*0*(\d+)", col), re.search(r"\[(.*)\]", col)
            if not m or not br or not any(k in br.group(1) for k in kws):
                continue
            q = int(m.group(1))
            for ri, r in enumerate(rows):
                a = r[col].strip()
                j = (0 if key[q][a] == "improvement1" else 1) if a in ("A", "B") else 2
                per_q[q - 1, j] += 1
                per_rater[ri, j] += 1
        tot = per_q.sum(0)
        # per-question majority between the two methods (tie votes ignored), as in user_study_results.md
        maj = ["ours" if r[0] > r[1] else "baseline" if r[1] > r[0] else "tie/split" for r in per_q]
        res[dim] = dict(unanimous_ours=int((per_q[:, 0] == len(rows)).sum()),
                        unanimous_base=int((per_q[:, 1] == len(rows)).sum()),
                        p_items=sign_test(maj.count("ours"), maj.count("baseline")),
                        p_raters=sign_test((per_rater[:, 0] > per_rater[:, 1]).sum(),
                                           (per_rater[:, 1] > per_rater[:, 0]).sum()),
                        n=int(tot.sum()), ours=tot[0] / tot.sum(), base=tot[1] / tot.sum(), tie=tot[2] / tot.sum(),
                        p=sign_test(tot[0], tot[1]), kappa=fleiss_kappa(per_q),
                        maj_ours=maj.count("ours"), maj_base=maj.count("baseline"), maj_tie=maj.count("tie/split"),
                        raters_pref_ours=int((per_rater[:, 0] > per_rater[:, 1]).sum()),
                        raters_pref_base=int((per_rater[:, 1] > per_rater[:, 0]).sum()))
    return len(rows), len(key), res


def user_study_table(n_raters, n_q, res):
    lines = [r"\begin{table}[t]", r"\centering", r"\small", r"\setlength{\tabcolsep}{4pt}",
             r"\begin{tabular}{lccc}", r"\toprule",
             r"Criterion & Proposed & \method{} & Tie \\", r"\midrule"]
    for dim in ("Prompt fidelity", "Image quality", "Structure preservation"):
        r = res[dim]
        n = r["n"]
        o, b, t = round(r["ours"] * n), round(r["base"] * n), round(r["tie"] * n)
        so, sb = f"{o} ({100 * r['ours']:.1f}\\%)", f"{b} ({100 * r['base']:.1f}\\%)"
        so, sb = (r"\textbf{" + so + "}", sb) if o > b else (so, r"\textbf{" + sb + "}")
        label = {"Prompt fidelity": "Follows the edit", "Image quality": "Clear and natural",
                 "Structure preservation": "Preserves the subject"}[dim]
        lines.append(f"{label} & {so} & {sb} & {t} ({100 * r['tie']:.1f}\\%)" + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}",
              rf"\caption{{Blind pairwise preferences ({n_q} pairs $\times$ {n_raters} participants = "
              rf"{n_q * n_raters} judgments per criterion).}}",
              r"\label{tab:user_study}", r"\end{table}"]
    return "\n".join(lines) + "\n"


# ----------------------------------------------------------------------------- main
def main():
    OUT.mkdir(parents=True, exist_ok=True)
    wide = load_metrics()
    rt = load_runtime()
    ps = paired_stats(wide)
    sg = subgroup_stats(wide)

    # per-image deltas, also used by make_figures.py
    per = wide.pivot_table(index="id", columns="metric", values=[BASE, OURS])
    per.columns = [f"{SHORT[m]}_{'base' if meth == BASE else 'ours'}" for meth, m in per.columns]
    per = per.reset_index()
    for k in SHORT.values():
        per[f"d_{k}"] = per[f"{k}_ours"] - per[f"{k}_base"]
    per["sub"] = per["id"].str[1:3]
    hints = json.loads((RES / "subject_hints_category8.json").read_text())
    per["hint"] = per["id"].map(lambda i: hints[i].split()[0])
    per["scene_hint"] = per["id"].isin(SCENE_HINTS)
    per.to_csv(OUT / "per_image.csv", index=False)

    rho, rho_p = stats.spearmanr(per["d_CLIP-W"], per["d_Struct"])
    n_raters, n_q, us = user_study()

    md = ["# Category 8 analysis (MasaCtrl vs. ours)\n",
          "Generated by `src/analyze_category8.py`. Scales: Struct x1e3, LPIPS x1e3, MSE x1e4, SSIM x1e2.\n",
          "## Paired comparison\n",
          "| Metric | n | MasaCtrl (mean ± sd) | Ours (mean ± sd) | Δ (ours−base) | 95% bootstrap CI | ours better | Wilcoxon p |",
          "|---|---|---|---|---|---|---|---|"]
    for k, r in ps.iterrows():
        md.append(f"| {SHORT[k]} | {int(r.n)} | {r.base:.2f} ± {r.base_sd:.2f} | {r.ours:.2f} ± {r.ours_sd:.2f} | "
                  f"{r.delta:+.2f} | [{r.ci_lo:+.2f}, {r.ci_hi:+.2f}] | {100 * r.ours_better:.0f}% | {fmt_p(r.wilcoxon_p)} |")
    b, o = rt[BASE], rt[OURS]
    md += ["", "## Runtime (s per edit, NTU TC2, same GPU)\n",
           f"- MasaCtrl: mean {b.mean():.2f}, median {np.median(b):.2f} (n={len(b)}; first call {b[0]:.1f}s includes warm-up)",
           f"- Ours: mean {o.mean():.2f}, median {np.median(o):.2f} (n={len(o)})",
           f"- Overhead: {100 * (o.mean() / b.mean() - 1):+.1f}% (median {100 * (np.median(o) / np.median(b) - 1):+.1f}%)",
           "", "## Trade-off\n",
           f"- Spearman correlation between per-image ΔCLIP-W and ΔStruct: rho = {rho:.2f} (p = {fmt_p(rho_p)})",
           f"- Images where ours improves CLIP-W: {(per['d_CLIP-W'] > 0).sum()}/80; "
           f"of these, structure distance also rises on {((per['d_CLIP-W'] > 0) & (per['d_Struct'] > 0)).sum()}",
           f"- Images where ours lowers CLIP-W: {(per['d_CLIP-W'] < 0).sum()}/80 "
           f"(ids: {', '.join(per.loc[per['d_CLIP-W'] < 0, 'id'])})",
           f"- ΔCLIP-E vs baseline CLIP-E: Spearman rho = {stats.spearmanr(per['CLIP-E_base'], per['d_CLIP-E'])[0]:.2f}; "
           f"mean ΔCLIP-E on the 40 images with the lowest baseline CLIP-E = "
           f"{per.nsmallest(40, 'CLIP-E_base')['d_CLIP-E'].mean():+.2f}, on the other 40 = "
           f"{per.nlargest(40, 'CLIP-E_base')['d_CLIP-E'].mean():+.2f}",
           f"- Of the 70 images with an unedited region: CLIP-E up & LPIPS worse = "
           f"{((per['d_CLIP-E'] > 0) & (per['d_LPIPS'] > 0)).sum()}, both better = "
           f"{((per['d_CLIP-E'] > 0) & (per['d_LPIPS'] < 0)).sum()}",
           "", "## Sub-groups (Δ = ours − MasaCtrl, 10 images each; PSNR on the images with an unedited region)\n",
           "| Sub-group | CLIP-W base→ours | ΔCLIP-W | Struct base→ours | ΔStruct | PSNR base→ours | ΔPSNR (n) | CLIP-E base→ours | ΔCLIP-E | CLIP-E improved |",
           "|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in sg.iterrows():
        md.append(f"| {r['name']} | {r['CLIP-W_base']:.2f}→{r['CLIP-W_ours']:.2f} | {r['d_CLIP-W']:+.2f} | "
                  f"{r['Struct_base']:.1f}→{r['Struct_ours']:.1f} | {r['d_Struct']:+.1f} | "
                  f"{r['PSNR_base']:.2f}→{r['PSNR_ours']:.2f} | {r['d_PSNR']:+.2f} ({r['n_PSNR']}) | "
                  f"{r['CLIP-E_base']:.2f}→{r['CLIP-E_ours']:.2f} | {r['d_CLIP-E']:+.2f} | {r['win_CLIP-E']}/10 |")
    sc, cl = per[per.scene_hint], per[~per.scene_hint]
    md += ["", "## Subject-hint quality\n",
           f"Hints flagged as naming a scene/adjective rather than an object ({len(sc)}): "
           + ", ".join(f"{i} ('{h}')" for i, h in zip(sc["id"], sc["hint"])),
           "",
           "| Hint | n | ΔCLIP-W | ΔStruct | ΔPSNR |", "|---|---|---|---|---|",
           f"| object hint | {len(cl)} | {cl['d_CLIP-W'].mean():+.2f} | {cl['d_Struct'].mean():+.1f} | {cl['d_PSNR'].mean():+.2f} |",
           f"| scene/adjective hint | {len(sc)} | {sc['d_CLIP-W'].mean():+.2f} | {sc['d_Struct'].mean():+.1f} | {sc['d_PSNR'].mean():+.2f} |",
           f"\nMann-Whitney U on ΔStruct (scene vs object): p = "
           f"{fmt_p(stats.mannwhitneyu(sc['d_Struct'], cl['d_Struct']).pvalue)}",
           "", f"## User study ({n_raters} raters × {n_q} pairs)\n",
           "| Criterion | Ours | MasaCtrl | Tie | sign-test p (judgments) | Fleiss κ | majority ours/base/tie | p (items) | raters preferring ours/base | p (raters) | unanimous ours/base |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    for dim, r in us.items():
        md.append(f"| {dim} | {100 * r['ours']:.1f}% | {100 * r['base']:.1f}% | {100 * r['tie']:.1f}% | "
                  f"{fmt_p(r['p'])} | {r['kappa']:.2f} | {r['maj_ours']}/{r['maj_base']}/{r['maj_tie']} | "
                  f"{fmt_p(r['p_items'])} | {r['raters_pref_ours']}/{r['raters_pref_base']} | {fmt_p(r['p_raters'])} | "
                  f"{r['unanimous_ours']}/{r['unanimous_base']} |")
    (OUT / "summary.md").write_text("\n".join(md) + "\n")

    TABLES.mkdir(parents=True, exist_ok=True)
    (TABLES / "main_results.tex").write_text(main_table(ps, rt))
    (TABLES / "subgroups.tex").write_text(subgroup_table(sg))
    (TABLES / "user_study.tex").write_text(user_study_table(n_raters, n_q, us))
    print("\n".join(md))


if __name__ == "__main__":
    main()
