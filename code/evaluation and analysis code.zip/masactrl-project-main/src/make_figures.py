"""Report figures from the existing category 8 outputs (run src/analyze_category8.py first).

Writes
  paper/figures/qualitative.{pdf,png}  source | MasaCtrl | ours on six user-study pairs
  paper/figures/clip_gain.{pdf,png}    per-image edited-region CLIP, MasaCtrl (x) vs. ours (y)

Source images are cropped from the user-study panels (PIE-Bench is not in the repo);
edited images are the lossless PNGs in results/baseline+improvement1/.
"""
import csv
import glob
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results" / "baseline+improvement1"
FIG = ROOT / "paper" / "figures"
BLUE, ORANGE = "#2a78d6", "#eb6834"      # categorical slots 1 and 2 (validated pair)
INK, MUTED = "#0b0b0b", "#52514e"

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 8, "mathtext.fontset": "stix", "svg.fonttype": "none", "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "pdf.fonttype": 42})

# (user-study question, short label); all six participants chose ours for "follows the edit" on each
EXAMPLES = [(2, "wall $\\rightarrow$ park"), (4, "moss $\\rightarrow$ rocks"),
            (8, "mountains $\\rightarrow$ sea"), (10, "snow $\\rightarrow$ leaves"),
            (6, "space $\\rightarrow$ desert"), (13, "add a cave")]
FAILURES = {}


def source_panel(q):
    """Left panel of the user-study image = the PIE-Bench source at 512x512."""
    im = Image.open(ROOT / "user_study" / "images" / f"Q{q:02d}.jpg").convert("RGB")
    return im.crop((16, 70, 528, 582))


CROP = (46, 46, 512, 512)  # same square crop on all three panels; hides the "Orig." tag of the study image


def edited(method_dir, pie_id):
    return Image.open(glob.glob(str(RES / method_dir / "**" / f"{pie_id}.png"), recursive=True)[0]).convert("RGB")


def qualitative():
    key = {int(r["question"]): r for r in csv.DictReader(open(ROOT / "user_study" / "answer_key_DO_NOT_SHARE.csv"))}
    fig, axes = plt.subplots(3, 6, figsize=(7.0, 3.95), gridspec_kw=dict(wspace=0.03, hspace=0.32))
    titles = ["Source", "MasaCtrl", "Proposed"]
    for n, (q, label) in enumerate(EXAMPLES):
        row, col0 = n // 2, 3 * (n % 2)
        pid = key[q]["pie_id"]
        for j, im in enumerate([source_panel(q), edited("baseline", pid), edited("improvement1", pid)]):
            ax = axes[row, col0 + j]
            ax.imshow(np.asarray(im.crop(CROP)))  # native resolution, no downsampling
            ax.set_xticks([]); ax.set_yticks([])
            for s in ax.spines.values():
                s.set_visible(False)
            if row == 0:
                ax.set_title(titles[j], fontsize=8, color=INK, pad=3)
        text = label + (f"  (failure: {FAILURES[q]})" if q in FAILURES else "")
        axes[row, col0 + 1].text(0.5, -0.07, text, transform=axes[row, col0 + 1].transAxes,
                                 ha="center", va="top", fontsize=7.5, color=INK, style="italic")
    FIG.mkdir(parents=True, exist_ok=True)
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"qualitative.{ext}", dpi=600, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def clip_gain():
    per = pd.read_csv(RES / "analysis" / "per_image.csv", dtype={"id": str})
    x, y = per["CLIP-E_base"], per["CLIP-E_ours"]
    up = y > x
    fig, ax = plt.subplots(figsize=(3.3, 2.75))
    lo, hi = 9, 36
    ax.plot([lo, hi], [lo, hi], color=MUTED, lw=0.8, ls="--", zorder=1)
    ax.scatter(x[up], y[up], s=14, color=ORANGE, edgecolor="white", lw=0.4, zorder=3,
               label=f"Proposed higher ({up.sum()})")
    ax.scatter(x[~up], y[~up], s=14, color=BLUE, edgecolor="white", lw=0.4, zorder=3,
               label=f"MasaCtrl higher ({(~up).sum()})")
    ax.text(lo + 1.2, hi - 1.5, "proposed better", fontsize=7, color=MUTED, va="top")
    ax.text(hi - 1.2, lo + 1.2, "MasaCtrl better", fontsize=7, color=MUTED, ha="right")
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi); ax.set_aspect("equal")
    ax.set_xlabel("CLIP-E, DDIM + MasaCtrl")
    ax.set_ylabel("CLIP-E, DDIM + proposed")
    ax.grid(color="#e6e5e0", lw=0.5, zorder=0); ax.set_axisbelow(True)
    for s_ in ("top", "right"):
        ax.spines[s_].set_visible(False)
    ax.legend(loc="lower right", bbox_to_anchor=(1.0, 0.08), frameon=False, fontsize=7, handletextpad=0.2)
    fig.tight_layout(pad=0.2)
    for ext in ("pdf", "png", "svg"):   # png at 600 dpi for Word; svg/pdf are vector
        fig.savefig(FIG / f"clip_gain.{ext}", dpi=900, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


if __name__ == "__main__":
    qualitative()
    clip_gain()
    print("wrote", FIG / "qualitative.pdf", FIG / "clip_gain.pdf")
