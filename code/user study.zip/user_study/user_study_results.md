# User study results

**PIE-Bench change background · 16 pairs · 6 raters · 96 judgments per criterion**

| Criterion | Ours | MasaCtrl | Tie | p (sign test, ties excluded) |
|---|---|---|---|---|
| Image quality | 45.8% | 30.2% | 24.0% | 0.10 |
| Prompt fidelity | 72.9% | 17.7% | 9.4% | < 0.001 |
| Structure preservation | 22.9% | 54.2% | 22.9% | < 0.001 |

**Per-question majority (16 questions):**

- Prompt fidelity: ours wins 12, MasaCtrl wins 2, tie 2
- Structure preservation: ours wins 4, MasaCtrl wins 9, tie 3
- Prompt fidelity is the one criterion on which all 6 raters chose ours over MasaCtrl more often than not.

> **Caveat:** the 96 judgments are treated as independent in the p-values, yet they stem from 6 raters × 16 pairs; read the p-values as indicative only.

---

## LaTeX table

```latex
\begin{table}[t]
\centering
\small
\begin{tabular}{lccc}
\toprule
Criterion & Ours & MasaCtrl & Tie \\
\midrule
Image quality & \textbf{45.8\%} & 30.2\% & 24.0\% \\
Prompt fidelity & \textbf{72.9\%} & 17.7\% & 9.4\% \\
Structure preservation & 22.9\% & \textbf{54.2\%} & 22.9\% \\
\bottomrule
\end{tabular}
\caption{User study on 16 randomly sampled PIE-Bench \emph{change background} pairs (6 participants, 96 judgments per criterion). Percentages are the share of pairwise judgments preferring each method.}
\label{tab:user_study}
\end{table}
```

---

## Paragraph for the report

```latex
\paragraph{User study.} Alongside the automatic metrics, we conducted a blinded pairwise user study. With a fixed random seed we drew 16 image pairs from the PIE-Bench \emph{change background} category, taking two from each of its eight sub-groups. Participants saw, for each pair, the source image, the target prompt, and the outputs of MasaCtrl and our method; PIE-Bench's editing instruction was shown only to make the intended edit easier to identify, and the two outputs appeared in random left/right order, balanced so that each method was ``A'' in half of the questions. They then picked the better result, or ``tie'', on three criteria: image quality, prompt fidelity, and preservation of the source subject. Six participants gave 96 judgments per criterion (Table~\ref{tab:user_study}). Prompt fidelity drew a preference for our method in 72.9\% of judgments against 17.7\% for MasaCtrl (sign test, $p<0.001$); the majority vote went to ours on 12 of the 16 pairs, and every participant favored it on this criterion. For image quality the preference for our method was smaller and non-significant (45.8\% vs.\ 30.2\%, $p=0.10$). Structure preservation, in contrast, favored MasaCtrl (54.2\% vs.\ 22.9\%, $p<0.001$). The intended trade-off accounts for this: once the background is released from the source image it can follow the new prompt, but the constraint keeping the edited subject identical to the source is thereby weakened. Given the study's small size and the non-independence of the judgments, we regard these results as supporting evidence for the automatic metrics rather than as a standalone result.
```
